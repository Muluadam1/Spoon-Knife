# Phone Card app.

## You can get the project either using git clone or by downloading the zip folder.

To download the project:
1. Go to the following link https://github.com/practicalit/phone-card.
2. Click on the green button that says Code.
3. From the drop down, select the download zip.
4. It will download the phone-card-master.zip file.
5. [Windows] Unzip the file by right clicking on it and selecting extract all
5. [Mac] doubleclick on the file and follow the path to see extracted files.
6. Open the folder with visual code and start hacking!

To use git clone:
1. issue git clone https://github.com/practicalit/phone-card.git
2. The above command will copy the folder phone-card to your directory.
3. Open the folder with visual code and start hacking!

>Your first task is to get the phone card app running locally and see what it is doing. All your tasks are listed under Task link in the page.

